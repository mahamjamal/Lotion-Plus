# add your save-note function here
import json
import boto3

dynamodb_resource = boto3.resource("dynamodb")
table = dynamodb_resource.Table("lotion-30153574")

def lambda_handler(note, context):

    user_email = note['headers']['email']
    access_token = note['headers']['access_token']
    note = json.loads(note['body'])


    # if not access_token:
    #     return {
    #         'statusCode': 401,
    #         'body': json.dumps({'message':'Unauthorized'})
    #     }

    try:
        table.put_item(
            Item={
            'email': user_email,
            'id': note['id'],
            'title': note['title'],
            'date': note['date'],
            'note': note['note'],
            'creationDate': note['creationDate']
            }
        )


        return  {
            "statusCode": 200,
                "body": json.dumps({
                    "message" : "Success! Note saved successfully"
                })

        }


    except Exception as exp:
        print("exception:  {exp}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": str(exp)
            })
        }

