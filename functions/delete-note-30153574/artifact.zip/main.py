# add your delete-note function here

import json
import boto3


dynamodb_resource = boto3.resource("dynamodb")
table = dynamodb_resource.Table("lotion-30153574")

def delete_item(email, note_id):

    user_email = email['headers']['email']
    access_token = email['headers']['access_token']
    note = json.loads(email['body'])


    if not access_token:
        return {
            'statusCode': 401,
            'body': json.dumps({'message':'Unauthorized'})
        }
    
    
    return table.delete_item(
        Key = {
        "email": email, 
        "id": note_id
        }
    )

def lambda_handler(event, context):
    body = json.loads(event["body"])
    note_id = body["id"]
    email = body["email"]


    try:

      delete_item(email,note_id)
      return {
            "statusCode": 200, 
            "body": json.dumps({
                "message": "success"

            })
      }


    except Exception as exp:
        print(exp)
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": str(exp)
            })
        }